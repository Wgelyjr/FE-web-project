from flask import Flask

# blueprint import
from database import database
from apps.felutils.views import felutils
from apps.chainlink.views import chainlink
from apps.fastsheet.views import fastsheet
from apps.batchback.views import batchback
from apps.hyperion.views import hyperion
from apps.hyperion.models import format_header


def create_app():
    app = Flask(__name__)
    # setup with the configuration provided
    app.config.from_object('config.DevelopmentConfig')

    # setup all our dependencies
    database.init_app(app)

    # register blueprint
    app.register_blueprint(felutils)
    app.register_blueprint(chainlink, url_prefix='/chainlink')
    app.register_blueprint(fastsheet, url_prefix='/fastsheet')
    app.register_blueprint(batchback, url_prefix='/batchback')
    app.register_blueprint(hyperion, url_prefix='/hyperion')
    app.jinja_env.globals.update(format_header=format_header)
    return app


if __name__ == "__main__":
    create_app().run()
else:
    app = create_app()

from flask import Blueprint, request, render_template, flash, redirect
from apps.batchback.models import *

batchback = Blueprint('batchback', __name__, template_folder="templates")


@batchback.before_request
def auth_only():
    if not request.cookies.get('fctoken'):
        flash('Auth required to visit BatchBack.')
        return redirect('/login')


@batchback.route('/', methods=['GET', 'POST'])
def home():
    if request.method == 'GET':
        return render_template('batchback.html')
    if request.method == 'POST':

        employee = request.form['employee']
        batch_id = request.form['batch_id']
        cause = request.form['cause']
        comment = request.form['comment']
        user = request.cookies.get('fcuser')

        for field in [employee, batch_id, cause, comment, user]:
            if not field:
                flash('Please enter all fields.')
                return redirect('/batchback')

        event = BatchEvent(batch_id=batch_id, cause=cause, user=user, target_user=employee, comment=comment)
        db.session.add(event)
        db.session.commit()

        flash(f'QCBatch "{batch_id}" added to log.')
        return redirect('/batchback')


@batchback.app_errorhandler(404)
def page_not_found():
    flash('Page not found. Please try again.')
    return redirect('/')

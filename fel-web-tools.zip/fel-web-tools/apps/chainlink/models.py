import json
import requests
from database.chainlink import OrderEvent, db


class Hefty:
    # for use with getting all orders - the /order and /order/ endpoints are VERY different
    # Each order is an object with attributes for order details
    # built-in methods for yielding handy bits of information, like full address

    def __init__(self, info_dictionary):
        # parses JSON input into attributes
        self.order_id = info_dictionary['id']
        self.package_type = info_dictionary['shippingPackageType']
        self.fulfilled = info_dictionary['fulfilled']
        self.fulfilled_date = info_dictionary['orderFulfillmentDate']
        self.is_cancelled = info_dictionary['cancelled']
        self.cancelled_date = info_dictionary['cancelledDate']
        self.ship_method = info_dictionary['shipmentMethod']
        self.ship_tracking = info_dictionary['shipmentTrackingID']
        self.city_address = info_dictionary['city']
        self.provincial_address = info_dictionary['province']
        self.postal_code = info_dictionary['postal_code']
        self.country = info_dictionary['country']
        self.ship_name = info_dictionary['shipToName']
        self.street_address = info_dictionary['address']
        self.phone = info_dictionary['phone']
        self.mobile_phone = info_dictionary['mobile_phone']
        self.fax = info_dictionary['fax']
        self.email = ['email']
        self.preferred_contact = info_dictionary['preferred_contact']
        self.ordered_date = info_dictionary['ordered_date']
        self.order_total = info_dictionary['order_total']
        self.status = info_dictionary['status']
        self.asset = info_dictionary['asset']
        self.client = info_dictionary['client']
        self.supply_quantity = 0
        self.probe_quantity = 0
        # supplies are an array... loop through array looking for packs
        for supply_order in info_dictionary['supplies']:
            if supply_order['name'] == 'Soil Sample Supplies Pack':
                self.supply_quantity += supply_order['quantity']
            if supply_order['name'] == 'Do you need a soil probe?':
                self.probe_quantity += supply_order['quantity']

    def formatted_address(self):
        # returns a string, formatted address for web view
        full_address = (f'''
            {self.ship_name} <\n>
            {self.street_address} <\n>
            {self.city_address} {self.provincial_address}, {self.postal_code}'''
                        )

        return full_address


class List(Hefty):
    # subclass of Hefty, used for full orders list
    def __init__(self, info_dictionary):
        super().__init__(info_dictionary)
        self.stripe_id = info_dictionary['stripe_id']
        self.midwest_id = info_dictionary['midwest_id']


class Order(Hefty):
    # subclass of hefty, used for individual orders
    def __init__(self, info_dictionary):
        super().__init__(info_dictionary)

    def get_attr(self):
        attributes = {
            'OrderID': str(self.order_id),
            'Name on order': str(self.ship_name),
            'Ordered Date': str(self.ordered_date[0:10]),
            'Sample Packs Requested': str(self.supply_quantity),
            'Moisture Probes Requested': str(self.probe_quantity),
            'Phone Number': str(self.phone),
            'Package Type': str(self.package_type),
            'Fulfilled': str(self.fulfilled),
            'Date Fulfilled': str(self.fulfilled_date),
            'Cancelled': str(self.is_cancelled),
            'Date Cancelled': str(self.cancelled_date),
            'Shipment Method': str(self.ship_method),
            'Tracking number': str(self.ship_tracking),
            'Street Address': str(self.street_address),
            'City': str(self.city_address),
            'State/Province': str(self.provincial_address),
            'Zip/Postal': str(self.postal_code),
            'Country': str(self.country)
        }
        return attributes


class HeftyAPI:
    # all API calls come from this object, pass it user token (from cookie) and use it like an engine
    # it'll only assign token as a variable and every method save for get active orders will yield parsed data

    def __init__(self, token):
        test_url = 'https://processing-api.farmcommand.com/token/'
        response = requests.get(test_url + f'?token={token}')
        if response.status_code == 200:
            self.token = token
        else:
            raise Exception('token_error')

    def get_active_orders(self):
        # pull all non-canceled/fulfilled orders from api
        # parses and loads response, organizes each order into list of HeftyOrder objects for easy handling
        # returns list of HeftyOrder objects
        base_url = \
            f'https://processing-api.farmcommand.com/" \
            hefty/order/?fulfilled=false&cancelled=false&token={self.token}&format=json' \
            '&supply_type=Supply'
        response = requests.get(base_url)
        if response.status_code != 200:
            return None
        raw_orders = json.loads(response.content)
        active_orders = []
        for order in raw_orders:
            active_orders.append(List(order))
        return active_orders

    def get_order(self, order_id):
        base_url = f'https://processing-api.farmcommand.com/hefty/order/{order_id}?token={self.token}&format=json'
        response = requests.get(base_url)
        if response.status_code == 404:
            return None
        raw_order = json.loads(response.content)
        print(response.status_code)
        order = Order(raw_order)
        return order

    def cancel_order(self, order_id, user, cancel_reason):
        url = f'https://processing-api.farmcommand.com/hefty/order/{order_id}?token={self.token}'
        payload = {"cancelled": True}
        response = requests.put(url, payload)
        print(response.status_code, response.json())
        if response.status_code == 201:
            ledger = OrderEvent(order_id=order_id, order_json=response.content, user=user, user_comment=cancel_reason,
                                user_action='cancel order')
            db.session.add(ledger)
            db.session.commit()
            return True
        else:
            return False

    def remove_cancel_status(self, order_id, user, comment):
        url = f'https://processing-api.farmcommand.com/hefty/order/{order_id}?token={self.token}'
        payload = {"cancelled": False}
        response = requests.put(url, payload)
        if response.status_code == 201:
            ledger = OrderEvent(order_id=order_id, order_json=response.content, user=user, user_comment=comment,
                                user_action='uncancelled order')
            db.session.add(ledger)
            db.session.commit()
            return True
        else:
            return False

    def remove_fulfill_status(self, order_id, user, comment):
        url = f'https://processing-api.farmcommand.com/hefty/order/{order_id}?token={self.token}'
        payload = {"fulfilled": False}
        response = requests.put(url, payload)
        if response.status_code == 201:
            ledger = OrderEvent(order_id=order_id, order_json=response.content, user=user, user_comment=comment,
                                user_action='unfulfilled order')
            db.session.add(ledger)
            db.session.commit()
            return True
        else:
            return False

    def fulfill_order(self, order_id, carrier, tracking_number, user):
        url = f'https://processing-api.farmcommand.com/hefty/order/{order_id}?token={self.token}'
        payload = {"fulfilled": True, "shipmentMethod": carrier, "shipmentTrackingID": tracking_number}
        response = requests.put(url, payload)
        if response.status_code == 201:
            ledger = OrderEvent(order_id=order_id, order_json=response.content, user=user,
                                user_comment=('carrier: ' + carrier + ', trk#: ' + tracking_number),
                                user_action='fulfill order')
            db.session.add(ledger)
            db.session.commit()
            return True
        else:
            return False

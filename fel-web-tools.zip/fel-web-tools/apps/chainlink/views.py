from flask import Blueprint, request, render_template, flash, redirect
from apps.chainlink.models import HeftyAPI

chainlink = Blueprint('chainlink', __name__, template_folder="templates")


@chainlink.before_request
def auth_only():
    if not request.cookies.get('fctoken'):
        flash('Auth required to visit ChainLink.')
        return redirect('/login')


@chainlink.route('/')
def home():
    # test with qa token 56663a7deb6c4ac7e48ee9e8e571a59dd7c3fc2d
    requester = HeftyAPI(request.cookies.get('fctoken'))
    orders = requester.get_active_orders()
    if not orders:
        flash('FarmCommand request failed. Try again later.')
        return redirect('/')
    orders = [y for y in orders if y.supply_quantity is not None or y.probe_quantity is not None]
    orders.sort(key=lambda x: x.order_id, reverse=False)
    return render_template('chainlink.html', orders=orders)


@chainlink.route('/nav')
def search():
    if not request.args.get('order_id'):
        flash('Please enter a value in the search bar.')
        return redirect('/chainlink')
    order_id = request.args['order_id']
    requester = HeftyAPI(request.cookies.get('fctoken'))
    order = requester.get_order(order_id)
    if not order:
        flash(f'Order {order_id} not found.')
        return redirect('/chainlink')
    return render_template('viewer.html', order=order)


@chainlink.route('/action/<order_id>', methods=['POST'])
def post_action(order_id):
    action = request.form['action']
    user = request.cookies.get('fcuser')
    request_engine = HeftyAPI(request.cookies.get('fctoken'))

    if action == 'cancel':
        comment = request.form['cancellation_reason']
        response_test = request_engine.cancel_order(order_id, user, comment)
        if response_test:
            flash(order_id + ' cancelled.')

    if action == 'fulfill':
        tracking = request.form['carrier_tracking']
        carrier = request.form['carrier_select']
        response_test = request_engine.fulfill_order(order_id, carrier, tracking, user)
        if response_test:
            flash(order_id + ' fulfilled.')
        else:
            flash('Error - order not fulfilled.')

    if action == 'un_cancel':
        comment = request.form['un_cancellation_reason']
        response_test = request_engine.remove_cancel_status(order_id, user, comment)
        if response_test:
            flash(order_id + ' uncancelled.')

    if action == 'un_fulfill':
        comment = request.form['un_fulfillment_reason']
        response_test = request_engine.remove_fulfill_status(order_id, user, comment)
        if response_test:
            flash(order_id + ' un-fulfilled.')
    return redirect('/chainlink')


@chainlink.app_errorhandler(404)
def page_not_found():
    flash('Page not found. Please try again.')
    return redirect('/')

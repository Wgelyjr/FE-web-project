# https://stackoverflow.com/questions/53962790/how-to-add-an-image-to-a-jinja-html-page

from flask import Blueprint, render_template, flash, redirect, request
import pyzint

fastsheet = Blueprint('fastsheet', __name__, template_folder="templates")


@fastsheet.route('/')
def main_page():
    if request.args.get('mz_id') or request.args.get('job_id'):
        job_id = str(request.args.get('job_id'))
        mz_id = str(request.args.get('mz_id'))

        payload = '{"fi":{"jid":' + job_id + ',"mzid":' + mz_id + '}}'
        symbol = pyzint.Barcode.AZTEC(payload)
        image_path = 'static/img/AZTEC.svg'
        with open(image_path, "wb") as bmp:
            bmp.write(symbol.render_svg())
        return render_template('fastsheet.html', image='img/AZTEC.svg')
    else:
        return render_template('fastsheet.html')

import requests
from flask import Blueprint, request, render_template, make_response, redirect, flash

felutils = Blueprint('felutils', __name__, template_folder="templates")


@felutils.route('/')
def home():
    return render_template('home.html')


@felutils.route('/login', methods=['GET', 'POST'])
def fcauth():
    if request.method == 'GET':
        return render_template('login.html')
    if request.method == 'POST':
        fcuser = request.form['username']
        fcpw = request.form['password']
        json = {"username": fcuser, "password": fcpw}
        url = f'https://processing-api.farmcommand.com/token-login/'
        response = requests.post(url, json=json)
        if response.status_code != 200:
            flash('Incorrect username or password.')
            return render_template('login.html')
        token = response.json()['token']
        resp = make_response(redirect('/'))
        resp.set_cookie('fctoken', token, max_age=21600)
        resp.set_cookie('fcuser', fcuser, max_age=21600)
        return resp


@felutils.app_errorhandler(404)
def page_not_found():
    flash('Page not found.')
    return redirect('/')

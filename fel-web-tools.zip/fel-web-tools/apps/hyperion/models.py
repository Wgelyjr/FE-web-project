from database.smv10 import *
from database.database import *


def format_header(descriptor):
    param_dict = {
        'AA_CATIONS': 'NH4-Ac. Cations',
        'BrayP1': 'Bray P',
        'BS': 'Base Saturation',
        'DTPAS': 'DTPA-S',
        'N+S': 'Nitrate + Sulfate',
        'OM': 'Organic Matter',
        'pHEC': 'pH/EC',
        'Ca_calc': 'Ca ppm',
        'K_calc': 'K ppm',
        'mg_calc': 'Mg ppm',
        'Na_calc': 'Na ppm',
        'BrayP1_calc': 'P ppm',
        'BS_Ca': 'Ca%',
        'BS_K': 'K%',
        'BS_Mg': 'Mg%',
        'BS_Na': 'Na%',
        'BS_tot': 'Total%',
        'CEC': 'CEC',
        'B_calc': 'B ppm',
        'Cu_calc': 'Cu ppm',
        'Fe_calc': 'Fe ppm',
        'Mn_calc': 'Mn ppm',
        'Zn_calc': 'Zn ppm',
        'NO3_calc': 'Nitrate ppm',
        'SO4_calc': 'Sulfate ppm',
        'OM_calc': 'OM%',
        'M3': 'Mehlich-3',
        'M3B_calc': 'B ppm',
        'M3Ca_calc': 'Ca ppm',
        'M3Cu_calc': 'Cu ppm',
        'M3Fe_calc': 'Fe ppm',
        'M3K_calc': 'K ppm',
        'M3Mg_calc': 'Mg ppm',
        'M3Mn_calc': 'Mn ppm',
        'M3Na_calc': 'Na ppm',
        'M3P_calc': ' P ppm',
        'M3Zn_calc': 'Zn ppm',
        'Bicarb_P': 'Olsen P',
        'Bicarb_P_calc': 'P ppm',
        'Cl': 'Chloride',
        'Cl_calc': 'Cl ppm'
    }

    if descriptor in param_dict:
        return param_dict[descriptor]
    else:
        return descriptor


class SMUser(db.Model):
    __tablename__ = 'sm_users'
    id = db.Column(db.Integer, primary_key=True)
    fc_user = db.Column(db.String)
    sm_user = db.Column(db.String)

import sqlalchemy.exc
from flask import Blueprint, request, render_template, Response, redirect, flash
from apps.hyperion.models import *
import re
import time
import pathlib
import os
import errno

sm_user_map = {
    'liam.ely': 'lely',
    'brian.parrish': 'bparrish',
    'mckayla.spiegeler': 'mspiegeler',
    'patrick.visser': 'pvisser'
}

hyperion = Blueprint('hyperion', __name__, template_folder="templates")


@hyperion.before_request
def auth_only():
    if not request.cookies.get('fctoken'):
        flash('Auth required to visit Hyperion.')
        return redirect('/login')
    if request.cookies.get('fcuser') not in sm_user_map:
        flash('Your account is not authorized for Hyperion.')
        return redirect('/')


@hyperion.route('/')
def home():
    # redirect from query params
    if request.args.get('order_id'):
        order_id = request.args['order_id']
        return redirect(f'/hyperion/{order_id}')
    # need to get orders and populate them
    orders = None
    attempt = 1
    while not orders:
        try:
            orders = SampleMaster.get_approvable_orders()
            if not orders:
                break
        except sqlalchemy.exc.OperationalError:
            attempt += 1
            time.sleep(3)
        if attempt >= 3:
            flash('Error in SQL DB communication. Please try again.')
            return redirect('/')
    for order in orders:
        order.get_result_info()
    return render_template('hyperion.html', orders=orders)


@hyperion.route('/<order_id>')
def viewer(order_id):
    response, order = input_cleaner(order_id)
    if response:
        order.get_result_info()
    else:
        return order
    if request.args:
        if request.args['action'] == 'download':
            html_file = render_template('grower_report.html', order=order)
            return Response(
                html_file,
                mimetype="text/csv",
                headers={
                    'Content-disposition':
                        f'attachment; filename={order.order_id}.html'
                }
            )
    else:
        order.get_approval_status()
        return render_template('approver_report.html', order=order)


@hyperion.route('/test_report/<order_id>')
def grower_report(order_id):
    response, order = input_cleaner(order_id)
    if response:
        order.get_result_info()
    else:
        return order

    if request.args:
        if request.args['action'] == 'download':
            html_file = render_template('grower_report.html', order=order)
            return Response(
                html_file,
                mimetype="text/csv",
                headers={
                    'Content-disposition':
                        f'attachment; filename={order.order_id}.html'
                }
            )
    else:
        return render_template('grower_report.html', order=order)


@hyperion.route('/approve/<order_id>')
def approve(order_id):
    response, order = input_cleaner(order_id)
    if response:
        order.get_result_info()
    else:
        return order

    report = render_template('grower_report.html', order=order)
    file_path = pathlib.Path(f'/reports/{order.customer_id}/{order.grower}/') # reporting directory

    try:
        os.makedirs(file_path)
    except OSError as exc:
        if exc.errno == errno.EEXIST and os.path.isdir(file_path):
            pass
        else:
            raise
    field_name = order.field_name.replace('/','-')
    with open(os.path.join(file_path, f'{order.order_id} - {field_name}.html'), 'w+') as file:
        file.writelines(data for data in report)

    fc_user = request.cookies.get('fcuser')
    order.approve_order(sm_user_map[fc_user])

    flash(f'{order.order_id} approved.')
    return redirect('/hyperion')


@hyperion.route('recall/<order_id>')
def recall(order_id):
    response, order = input_cleaner(order_id)
    if response:
        order.get_result_info()
    else:
        return order
    order.recall_order()
    flash(f'{order.order_id} recalled.')
    return redirect('/hyperion')


@hyperion.errorhandler(404)
def error():
    flash('Check your URL and try again.')
    return redirect('/hyperion')


# General Functions

def input_cleaner(order_id):
    input_test = re.search('[Uu]\d\d\d\d\d\d_\d\d\d', order_id)
    if not input_test:
        flash('Improper order number.')
        return False, redirect('/hyperion')
    order = Order(order_id)
    order.get_order_details()
    if not order.order_id:
        flash('OrderID not found.')
        return False, redirect('/hyperion')
    if not order.samples:
        flash('No samples in order.')
        return False, redirect('/hyperion')
    return True, order

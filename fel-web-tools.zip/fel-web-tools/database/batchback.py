from database.database import db
import datetime


class BatchEvent(db.Model):
    __tablename__ = 'batchback'

    id = db.Column(db.Integer, primary_key=True, nullable=False)
    batch_id = db.Column(db.String, nullable=False)
    cause = db.Column(db.String, nullable=False)
    user = db.Column(db.String, nullable=False)
    date = db.Column(db.String, nullable=False)
    target_user = db.Column(db.String, nullable=False)
    comment = db.Column(db.String, nullable=False)

    def __init__(self, batch_id, user, cause, target_user, comment):
        self.batch_id = batch_id
        self.cause = cause
        self.user = user
        self.date = datetime.datetime.now()
        self.target_user = target_user
        self.comment = comment

from database.database import db
import datetime


class OrderEvent(db.Model):
    # SQLite table for keeping a ledger of actions taken
    __tablename__ = 'order_events'
    id = db.Column(db.Integer, primary_key=True)
    order_id = db.Column(db.Integer, nullable=False)
    order_json = db.Column(db.BLOB, nullable=False)
    event_date = db.Column(db.DateTime, nullable=False)
    user = db.Column(db.Text, nullable=False)
    user_comment = db.Column(db.Text, nullable=False)
    user_action = db.Column(db.Text,nullable=False)

    def __init__(self, order_id, order_json, user, user_comment, user_action):
        self.order_id = order_id
        self.event_date = datetime.datetime.now()
        self.order_json = order_json
        self.user = user
        self.user_comment = user_comment
        self.user_action = user_action

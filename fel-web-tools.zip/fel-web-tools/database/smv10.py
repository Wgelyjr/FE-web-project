from sqlalchemy import create_engine



class SampleMaster:
    # base object with engine information - to be passed to Order object
    engine = create_engine('mssql+pyodbc://webtools:c1nnamon@CERES/SMv10?driver=ODBC+Driver+17+for+SQL+Server',
                           pool_pre_ping=True)

    @staticmethod
    def get_approvable_orders():
        # returns a list of approvable orders as order objects
        order_list = []
        with SampleMaster.engine.connect() as connection:
            response = connection.execute(
                '''
                SELECT
                    OrderID
                FROM
                    SMSU.FEL_vw_ReportableOrders
                ORDER BY
                    OrderID ASC
                '''
            )
            if not response:
                return None
            for row in response:
                order = Order(row[0])
                order.get_result_info()
                order_list.append(order)
        return order_list


class Order(SampleMaster):

    def __init__(self, order_id):
        # assigning initial required field info
        self.order_id = None
        with self.engine.connect() as connection:
            response = connection.execute(
                f'''
                SELECT 
                    OrderID,
                    CustomerID,
                    CustomerContact,
                    InvoiceCustomerContact,
                    InvoiceCustomerID,
                    Commnt
                FROM
                    SMSU.Orders
                WHERE
                    OrderID = '{order_id}'
                '''
            )
            for row in response:
                self.order_id = row[0]
                self.customer_id = row[1]
                self.customer_contact = row[2]
                self.invoice_customer_contact = row[3]
                self.invoice_customer_id = row[4]
                self.comment = row[5]

            # declaring some placeholder variables
            self.approved = None
            self.grower = None
            self.subfield_id = None
            self.matrix = None
            self.date_collected = None
            self.field_name = None
            self.zone_count = None
            self.date_received = None
            self.priority = None
            self.sample_count = None
            self.latitude = None
            self.longitude = None
            self.sampler = None
            self.preliminary = False
            self.samples = []
            self.test_structure = dict()  # to be replaced with a dictionary of Test : [params]
            self.test_row_1 = dict()  # for grower report breakout - test struct broken into two
            self.test_row_2 = dict()

    def __str__(self):
        return self.order_id

    def get_order_details(self):
        """
        runs query on self.order_id to get order details and populate sample information
        """
        with self.engine.connect() as connection:
            response = connection.execute(
                f'''
                SELECT
                    SampleNumber,
                    OrderDetails_User9,
                    Site,
                    CustomerSampleNumber,
                    Latitude,
                    Longitude,
                    Collector,
                    Matrix,
                    CollectDate,
                    ReceiveDate,
                    Priority,
                    Location,
                    OrderDetails_User1,
                    OrderDetails_User2
                FROM
                    SMSU.OrderDetails
                WHERE
                    OrderID = '{self.order_id}'
                '''
            )
            for row in response:
                while not self.samples:
                    self.field_name = row[3]
                    self.latitude = row[4]
                    self.longitude = row[5]
                    self.sampler = row[6]
                    self.matrix = row[7]
                    self.date_collected = row[8]
                    self.date_received = row[9]
                    self.priority = row[10]
                    self.grower = row[12]
                    self.subfield_id = row[13]
                    break
                self.samples.append(Sample(
                    order_id=self.order_id,
                    sample_number=row[0],
                    bag_number=row[1],
                    zone=row[2],
                    depth=row[11]
                ))

    def get_result_info(self):
        with self.engine.connect() as connection:
            response = connection.execute(
                f'''
                SELECT
                    SampleNumber,
                    Test,
                    [param],
                    method,
                    result,
                    numericresult,
                    units,
                    sortorder
                FROM
                    SMSU.Results
                WHERE
                    SMSU.Results.OrderID = '{self.order_id}'
                    AND
                    SMSU.Results.Report = 1
                ORDER BY CASE 
                    WHEN 
                        Test = 'OM' THEN 1 
                    WHEN
                        TEST = 'BrayP1' THEN 2
                    WHEN
                        Test = 'Bicarb_P' THEN 3
                    WHEN
                        Test IN ('AA_CATIONS','M3','BrayPK') THEN 6
                    WHEN
                        Test = 'pHEC' THEN 4
                    WHEN
                        Test = 'BufferpH' THEN 5
                    WHEN
                        Test = 'BS' THEN 7
                    ELSE 8 END, test
                '''  # SORT HAPPENS HERE ^
            )
            if not self.samples:
                self.get_order_details()
            for row in response:
                # first we skim the response for test structure
                test = row[1]
                param = row[2]
                if test in self.test_structure:
                    if param not in self.test_structure[test]:
                        self.test_structure[test].append(param)
                    else:
                        pass
                else:
                    self.test_structure[test] = list()
                    self.test_structure[test].append(param)
                # now we see if any results are missing - makes the order a preliminary order
                while not self.preliminary:
                    test_result = row[5]
                    if not test_result:
                        self.preliminary = True
                    else:
                        break
                # then it's time to actually generate result objects
                for sample in self.samples:
                    if sample.sample_number == row[0]:
                        sample.results.append(
                            Result(
                                order_id=self.order_id,
                                sample_number=row[0],
                                test=row[1],
                                param=row[2],
                                method=row[3],
                                result=row[4],
                                numeric_result=row[5],
                                units=row[6],
                                sort_order=row[7]
                            )
                        )
        # self.get_ph_values()
        # self.update_boron()

    def get_ph_values(self):
        ph_list = []
        for sample in self.samples:
            for result in sample.results:
                if result.param == 'pH':
                    sample.ph = result.numeric_result
                    ph_list.append(result.numeric_result)
                    break
        ph_average = sum(ph_list) / len(ph_list)
        for sample in self.samples:
            sample.ph_field = ph_average

    def update_boron(self):
        for sample in self.samples:
            if sample.boron_status:
                break
            if sample.ph:
                ph = sample.ph
            else:
                ph = sample.ph_field
            for result in sample.results:
                if result.param == 'B_calc':
                    # Format(rs!result.Value * ((-0.442 * phaverage) + 3.984), "0.0") ORIGINAL CALC
                    # Patrick's study origin - derives HWS B result
                    result.numeric_result = result.numeric_result * ((0 - 0.442 * ph) + 3.984)
                    sample.boron_status = True
                    break

    def mark_preliminary(self):
        self.preliminary = True

    def show_results(self):
        # displays all results for an order
        for sample in self.samples:
            for result in sample.results:
                if not sample.results:
                    pass
                print(result)

    def approve_order(self, user):
        with self.engine.connect() as connection:
            connection.execute(
                f'''
                UPDATE
                    SMSU.DepartmentChain
                SET
                    SMSU.DepartmentChain.Status = 1,
                    SMSU.DepartmentChain.DoneEmployeeID = '{user}',
                    SMSU.DepartmentChain.DoneDate = GETDATE()
                FROM
                    SMSU.DepartmentChain
                WHERE
                    SMSU.DepartmentChain.OrderID = '{self.order_id}' AND SMSU.DepartmentChain.Department = 'Reporting';
                UPDATE
                    SMSU.SampleDetails
                SET
                    SMSU.SampleDetails.CurrentDepartment = 3
                FROM
                    SMSU.SampleDetails
                WHERE
                    SMSU.SampleDetails.OrderID = '{self.order_id}';
                '''
            )
        return

    def get_approval_status(self):
        with self.engine.connect() as connection:
            result = connection.execute(
                f'''
                SELECT
                    MIN(Status)
                FROM
                    SMSU.DepartmentChain
                WHERE
                    SMSU.DepartmentChain.OrderID = '{self.order_id}'
                    AND
                    SMSU.DepartmentChain.Department = 'Reporting'
                GROUP BY
                    SMSU.DepartmentChain.OrderID
                '''
            )
            for row in result:
                if row[0] == 0:
                    self.approved = False
                if row[0] == 1:
                    self.approved = True

    def recall_order(self):
        with self.engine.connect() as connection:
            connection.execute(
                f'''
                UPDATE 
                    SMSU.DepartmentChain
                SET 
                    SMSU.DepartmentChain.Status = 0, 
                    SMSU.DepartmentChain.HaveEmployeeID = Null, 
                    SMSU.DepartmentChain.HaveDate = Null, 
                    SMSU.DepartmentChain.DoneEmployeeID = Null, 
                    SMSU.DepartmentChain.DoneDate = Null
                WHERE 
                    SMSU.DepartmentChain.OrderID = '{self.order_id}' AND 
                    SMSU.DepartmentChain.Department ='Reporting'
                '''
            )
        return


class Sample:
    # to be used internal to the Order object - order contains list of Sample objects
    def __init__(
            self,
            order_id,
            sample_number,
            bag_number,
            zone,
            depth
    ):
        self.order_id = order_id
        self.sample_number = sample_number
        if bag_number == None:
            self.bag_number = '-'
        else:
            self.bag_number = bag_number
        self.zone = zone
        self.depth = depth
        self.results = []
        self.ph = None
        self.ph_field = None
        self.boron_status = False  # False when boron has not been calculated, true otherwise

    def report_result(self, filter_param):
        # returns a result object that matches input parameter
        target = [result for result in self.results if result.param == filter_param]
        if not target:
            return '-'
        if not target[0].numeric_result:
            return 'NEED'
        if target[0].numeric_result > 1000:
            return round(target[0].numeric_result)
        if target[0].numeric_result > 100:
            return round(target[0].numeric_result, 1)
        return round(target[0].numeric_result, 2)

    def __str__(self):
        return self.sample_number


class Result:
    def __init__(self, order_id, sample_number, test, param, result, numeric_result, units, sort_order, method):
        self.order_id = order_id
        self.sample_number = sample_number
        self.test = test
        self.param = param
        self.result = result
        self.numeric_result = numeric_result
        self.units = units
        self.sort_order = sort_order
        self.method = method

    def __str__(self):
        return str(f'{self.sample_number}, {self.test}, {self.param}, {self.numeric_result}')
